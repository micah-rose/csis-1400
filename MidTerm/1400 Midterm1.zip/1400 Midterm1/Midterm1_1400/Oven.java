/******************
* Author: Micah L
*
* Midterm1: Oven
*******************/

public class Oven{

   // fields
   private boolean on;
   private int temperature;

   // constant
   public static final int MIN_BAKE = 170;
   
   // methods
   public void setTemperature (int t){
      
     if (temperature >=0){
        temperature = t;
     }
   }
   
   public void bake(){
   
     if (temperature >= MIN_BAKE){
         System.out.println("Baking at" + temperature + "F");
         on = true;
     }

     if (temperature <= MIN_BAKE){
         System.out.println("Baking requires at least 170 F");
         on = false;
     }
   }
   
   public void off(){
     setTemperature(0);
   }
   
   public String toString(){
      String s = "";
      
      if (on = true){
        s = "on temperature = " + temperature;
      }
      if (temperature < MIN_BAKE){ 
        s = "off temperature = 0";
      }   
      
      return s;
   }
}