/********************
* Author: Micah L
*
* Midterm1 Exercise
*********************/

public class Exercise {
   public static void main(String[] args){
      System.out.println("Hello World!!");
   }
}